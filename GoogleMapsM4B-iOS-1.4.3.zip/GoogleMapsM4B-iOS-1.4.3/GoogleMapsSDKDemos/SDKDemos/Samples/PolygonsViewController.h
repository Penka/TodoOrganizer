#import <UIKit/UIKit.h>
#import <GoogleMapsM4B/GoogleMaps.h>

@interface PolygonsViewController : UIViewController<GMSMapViewDelegate>

@end
