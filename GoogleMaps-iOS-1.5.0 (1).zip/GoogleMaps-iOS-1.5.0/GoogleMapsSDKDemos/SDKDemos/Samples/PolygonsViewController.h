#import <UIKit/UIKit.h>

#import <GoogleMaps/GoogleMaps.h>

@interface PolygonsViewController : UIViewController<GMSMapViewDelegate>

@end
